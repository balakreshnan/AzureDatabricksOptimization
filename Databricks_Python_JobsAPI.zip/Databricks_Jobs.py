from databricks_cli.jobs.api import JobsApi
from databricks_cli.runs.api import RunsApi
from databricks_cli.sdk.api_client import ApiClient
import json

workspace = "datman"

config = json.load(open('config.json','r'))
workspace_config = config[workspace]

#host = 'https://adb-4798020300133105.5.azuredatabricks.net' #datman
#token = ''

host = workspace_config['host']
token = workspace_config['token']

api_client = ApiClient(
  host  = host,
  token = token
)

jobs_api = JobsApi(api_client)
jobs_list = jobs_api.list_jobs()

runs_api = RunsApi(api_client)

runs = {'runs':[]}
cnt = 1

for job in jobs_list['jobs']:
    run_list = runs_api.list_runs(job_id=job['job_id'], active_only=False, completed_only=True, offset=0, limit=1)
    if  'runs' in run_list:
        print(f"({cnt}) Job ID:{job['job_id']} has more {run_list['has_more']} - Returned Runs: {len(run_list['runs'])}")
        cnt+=1
        for run in run_list['runs']:
            runs['runs'].append(run)


#print(runs)
print("Totoal Runs: " + str(len(runs['runs'])))
output_file = open(f'{workspace}_runs.json','w')
json.dump(runs,output_file,indent=6)



