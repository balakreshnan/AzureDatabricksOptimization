from databricks_cli.jobs.api import JobsApi
from databricks_cli.runs.api import RunsApi
from databricks_cli.sdk.api_client import ApiClient
from databricks_cli.clusters.api import ClusterApi
import json


## Select Databricks Workspace from Config file ##
workspace = "cscrm"


## Load workspace settings from config file ##
config = json.load(open('config.json','r'))
workspace_config = config[workspace]


host = workspace_config['host']
token = workspace_config['token']


### Init Databrick API SDK Cliets ##
api_client = ApiClient(
  host  = host,
  token = token
)

jobs_api = JobsApi(api_client)
jobs_list = jobs_api.list_jobs()

runs_api = RunsApi(api_client)


### Init Loop Variables ##
runs = {'runs':[]}
cnt = 1

for job in jobs_list['jobs']:
    run_list = runs_api.list_runs(job_id=job['job_id'], active_only=False, completed_only=True, offset=0, limit=1)
    if  'runs' in run_list:
        print(f"({cnt}) Job ID:{job['job_id']} has more {run_list['has_more']} - Returned Runs: {len(run_list['runs'])}")
        cnt+=1
        for run in run_list['runs']:
            if run['state']['life_cycle_state'] != 'SKIPPED':
              run['execution_duration_mins'] = (run['execution_duration']/(1000*60))%60
              runs['runs'].append(run)


### Save Run JSON ###
print("Totoal Runs: " + str(len(runs['runs'])))
output_file = open(f'results/{workspace}_runs.json','w')
json.dump(runs,output_file,indent=6)

### Save Cluster JSON ###
cluster_api = ClusterApi(api_client)
cluster_list = cluster_api.list_clusters()
output_file = open(f'results/{workspace}_cluster_list.json','w')
json.dump(cluster_list,output_file,indent=6)



