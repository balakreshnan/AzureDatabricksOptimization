from databricks_cli.jobs.api import JobsApi
from databricks_cli.runs.api import RunsApi
from databricks_cli.sdk.api_client import ApiClient
from databricks_cli.clusters.api import ClusterApi
import pymongo
import json



## Select Databricks Workspace from Config file ##
workspace = "data"


## Load workspace settings from config file ##
config = json.load(open('config.json','r'))
workspace_config = config[workspace]

host = workspace_config['host']
token = workspace_config['token']


### Init Databrick API SDK Cliets ##
api_client = ApiClient(
  host  = host,
  token = token
)

jobs_api = JobsApi(api_client)
jobs_list = jobs_api.list_jobs()

runs_api = RunsApi(api_client)


## Connect to MongoDB DB ##
db = pymongo.MongoClient('mongodb://localhost:27017').optimization


### Init Loop Variables ##
cnt = 1
jobs = []

for job in jobs_list['jobs']:
    job_json = job
    job_json['workspace'] = workspace
    run_list = runs_api.list_runs(job_id=job['job_id'], active_only=False, completed_only=True, offset=0, limit=10)
    runs = []
    if  'runs' in run_list:
        print(f"({cnt}) Job ID:{job['job_id']} has more {run_list['has_more']} - Returned Runs: {len(run_list['runs'])}")
        cnt+=1
        for run in run_list['runs']:
          if run['state']['life_cycle_state'] != 'SKIPPED':
            run['execution_duration_mins'] = (run['execution_duration']/(1000*60))%60
            run['setup_duration_min'] = (run['setup_duration']/(1000*60))%60
            run['cleanup_duration_min'] = (run['cleanup_duration']/(1000*60))%60
            run['total_duration_min'] = run['setup_duration_min'] + run['execution_duration_mins']+run['cleanup_duration_min']


            runs.append(run)
    
    job_json['runs'] = runs
    jobs.append(job_json)   
    

print("Saving to MongoDB..")
db.databricks.insert_many(jobs)


print("Finished MongoDB Write")



